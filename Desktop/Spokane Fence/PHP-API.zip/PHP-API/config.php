<?php
return array(
    'authorizationRequestUrl' => 'https://appcenter.intuit.com/connect/oauth2',
    'tokenEndPointUrl' => 'https://oauth.platform.intuit.com/oauth2/v1/tokens/bearer',
    'client_id' => 'Q0TQ6lCBvimkFOSwfhUJtgUhTG2jTdS4eK7F2BxndS0VQYqNqy',
    'client_secret' => 'fSpYAppFDSo3Bv65caMDj4UM2WFuyKDkBwECMVHx',
    'oauth_scope' => 'com.intuit.quickbooks.accounting',
    'oauth_redirect_uri' => 'http://localhost:3000/redirect',
    'realmId' => '123146326775424',
    'file' => 'database.db'
);
